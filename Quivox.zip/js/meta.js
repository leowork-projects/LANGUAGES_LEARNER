/* =====================================================
   QUIVOX — ПРОГРЕСС + МАГАЗИН + ПРОФИЛЬ + ОТЧЁТЫ
   ===================================================== */
"use strict";

/* ================= ПРОГРЕСС ================= */
LQ.pages.progress = () => {
  const s = LQ.state, L = LQ.level();
  const tlangs = LQ.targetLangs();                       // выбранные языки (учитывает «все»)
  const learnedCards = LQ.ALL.flatMap(w => tlangs.filter(l => LQ.isLearned(w.id, l)).map(l => ({ w, l })));
  const hard = tlangs.flatMap(l => LQ.mistakeWords(l).map(w => ({ w, l })));

  // активность за 7 дней
  const days = [...Array(7)].map((_,i) => {
    const d = new Date(Date.now() - (6-i)*864e5);
    const k = LQ.dayKey(d);
    return { n: s.stats.daily[k]?.c || 0, d: `${d.getDate()}.${String(d.getMonth()+1).padStart(2,"0")}` };
  });
  const maxD = Math.max(1, ...days.map(x => x.n));

  LQ.qs("#page-progress").innerHTML = `
    <h2 class="section-title">📈 ${LQ.t("pr.title")} <small>${LQ.t("pr.masterOf",{lang:LQ.langName(s.target)})}</small></h2>

    <div class="stat-cards">
      <div class="card stat-card"><span class="ic">📚</span><div class="v">${learnedCards.length}</div><div class="l">${LQ.t("home.s1")}</div></div>
      <div class="card stat-card"><span class="ic">🎯</span><div class="v">${s.stats.tests}</div><div class="l">${LQ.t("home.s2")}</div></div>
      <div class="card stat-card"><span class="ic">⏱️</span><div class="v">${s.stats.exams}</div><div class="l">${LQ.t("nav.exam")}</div></div>
      <div class="card stat-card"><span class="ic">🔥</span><div class="v">${s.stats.streak.n}</div><div class="l">${LQ.t("home.streak")}</div></div>
    </div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(290px,1fr));margin-top:14px">
      <div class="card">
        <h3 class="section-title" style="margin-top:0">📊 ${LQ.t("pr.themeProg")}</h3>
        ${WORDS_DB.themes.map(th => {
          const tw = LQ.themeWords(th.id);
          const tot = tw.length * tlangs.length;
          const ld = tw.reduce((a,w) => a + tlangs.filter(l => LQ.isLearned(w.id, l)).length, 0);
          const pct = tot ? Math.round(ld/tot*100) : 0;
          return `<div class="theme-bar-row">
            <div class="tb-head"><span>${th.icon} ${th.title[s.uiLang]||th.title.ru}</span><span>${ld}/${tot} · ${pct}%</span></div>
            <div class="progress-track"><div class="progress-bar" style="width:${pct}%"></div></div>
          </div>`; }).join("")}
      </div>
      <div class="card">
        <h3 class="section-title" style="margin-top:0">📅 ${LQ.t("pr.act")}</h3>
        <div class="bars7">
          ${days.map(x => `<div class="bar7"><span class="n">${x.n||""}</span><div class="b" style="height:${x.n/maxD*100}%"></div><span class="d">${x.d}</span></div>`).join("")}
        </div>
        <div style="margin-top:16px">
          <div class="setup-label">🏅 ${LQ.t("lvl."+Math.min(L.lvl,10))} — Lv ${L.lvl}</div>
          <div class="progress-track" style="margin-top:8px"><div class="progress-bar" style="width:${L.pct}%"></div></div>
          <div class="muted" style="font-size:.75rem;margin-top:6px">${s.xp} XP${L.next ? " · " + LQ.t("home.toNext",{n:L.lvl+1}) : ""}</div>
        </div>
      </div>
    </div>

    <h3 class="section-title">✅ ${LQ.t("pr.learned")} <small>${learnedCards.length}</small></h3>
    <div class="card">
      ${learnedCards.length ? `<div class="chip-cloud">${learnedCards.map(x =>
        `<span class="word-chip">${LQ.FLAG[x.l]} ${LQ.esc(x.w[x.l])}<span class="wp-speak" data-spk="${x.w.id}" data-l="${x.l}">🔊</span></span>`).join("")}</div>`
      : `<p class="muted">${LQ.t("pr.empty")}</p>`}
    </div>

    <h3 class="section-title">⚠️ ${LQ.t("pr.hard")} <small>${hard.length}</small></h3>
    <div class="card">
      ${hard.length ? `
        <div class="chip-cloud">${hard.map(x =>
          `<span class="word-chip hard">${LQ.FLAG[x.l]} ${LQ.esc(x.w[x.l].replace(/\([^)]*\)/g,"").trim())}<span class="wp-speak" data-spk="${x.w.id}" data-l="${x.l}">🔊</span></span>`).join("")}</div>
        <button class="btn primary" id="hardTrain" style="margin-top:14px">🔁 ${LQ.t("res.retry")} (${hard.length})</button>`
      : `<p class="muted">${LQ.t("res.noMist")}</p>`}
    </div>

    <h3 class="section-title">⏱️ ${LQ.t("pr.exams")}</h3>
    <div class="card">
      ${s.exams.length ? `<table class="mini"><thead><tr><th>${LQ.t("pr.date")}</th><th>${LQ.t("pr.acc")}</th><th>${LQ.t("pr.time")}</th><th>${LQ.t("pr.grade")}</th></tr></thead>
        <tbody>${s.exams.map(e => `<tr><td>${new Date(e.date).toLocaleDateString(s.uiLang)}</td><td>${e.acc}%</td><td>${LQ.fmtTime(e.time)}</td><td><b class="${e.acc>=80?"glow-text":"muted"}">${e.grade}</b></td></tr>`).join("")}</tbody></table>`
      : `<p class="muted">${LQ.t("pr.empty")}</p>`}
    </div>

    <h3 class="section-title">🏅 ${LQ.t("pr.ach")} <small>${s.ach.length}/${LQ.ACH.length}</small></h3>
    <div class="ach-grid">
      ${LQ.ACH.map(a => `<div class="card ach ${s.ach.includes(a.id)?"unlocked":""}">
        <div class="ai">${a.ic}</div><h4>${LQ.t("ach."+a.id)}</h4><p>${LQ.t("ach."+a.id+"_d")} · +${a.reward} 🪙</p>
      </div>`).join("")}
    </div>

    <div style="margin-top:22px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn primary" id="dlReport">${LQ.t("pr.report")}</button>
      <button class="btn" id="pgExport">${LQ.t("prf.export")}</button>
      <button class="btn" id="pgImportBtn">${LQ.t("prf.import")}</button>
      <input type="file" id="pgImport" accept=".json" class="hidden">
    </div>`;

  LQ.qsa("#page-progress .wp-speak").forEach(b => b.onclick = () => { const l = b.dataset.l || tlangs[0]; LQ.speak(LQ.byId(b.dataset.spk)[l], l); });
  const ht = LQ.qs("#hardTrain");
  if (ht) ht.onclick = () => startSession({ mode:"choice", dir:{q:s.base, a:s.target}, pool:LQ.shuffle([...new Set(hard.map(x=>x.w))]), pageId:"#page-progress", isExam:false });
  LQ.qs("#dlReport").onclick = downloadReport;
  LQ.qs("#pgExport").onclick = LQ.exportData;
  const pgImp = LQ.qs("#pgImport");
  LQ.qs("#pgImportBtn").onclick = () => pgImp.click();
  pgImp.onchange = () => pgImp.files[0] && LQ.importData(pgImp.files[0]);
};

/* ================= ОТЧЁТ (генерация HTML-документа) ================= */
function downloadReport() {
  const s = LQ.state, L = LQ.level();
  const langs = ["en","es","pt"];
  const themeRows = WORDS_DB.themes.map(th => {
    const cells = langs.map(lang =>
      `<td>${th.words.filter(w => LQ.isLearned(w.id, lang)).length}/${th.words.length}</td>`).join("");
    return `<tr><td><b>${th.icon} ${th.title[s.uiLang]||th.title.ru}</b></td>${cells}</tr>`;
  }).join("");

  const html = `<!DOCTYPE html><html lang="${s.uiLang}"><head><meta charset="utf-8"><title>QUIVOX Report</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;max-width:820px;margin:30px auto;padding:0 20px;color:#1e293b}
h1{color:#8b5cf6} h2{color:#0ea5e9;border-bottom:2px solid #e2e8f0;padding-bottom:6px;margin-top:32px}
table{border-collapse:collapse;width:100%;margin-top:10px} td,th{border:1px solid #e2e8f0;padding:8px 12px;text-align:left}
th{background:#f1f5f9}.stat{display:inline-block;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 20px;margin:4px;text-align:center}
.stat b{display:block;font-size:1.5rem;color:#8b5cf6}.foot{margin-top:40px;color:#94a3b8;font-size:.85rem}</style></head><body>
<h1>🔮 QUIVOX — ${LQ.t("pr.report").replace("📄 ","")}</h1>
<p>👤 <b>${LQ.esc(s.user.name)}</b> · 📅 ${new Date().toLocaleString(s.uiLang)}</p>
<div>
  <span class="stat"><b>${L.lvl}</b>${LQ.t("lvl."+Math.min(L.lvl,10))}</span>
  <span class="stat"><b>${s.xp}</b>XP</span>
  <span class="stat"><b>${s.coins}</b>🪙</span>
  <span class="stat"><b>${s.stats.streak.n}</b>🔥</span>
  <span class="stat"><b>${s.stats.tests}</b>🎯</span>
  <span class="stat"><b>${s.stats.exams}</b>⏱️</span>
</div>
<h2>📚 ${LQ.t("pr.themeProg")}</h2>
<table><tr><th></th><th>EN 🇬🇧</th><th>ES 🇪🇸</th><th>PT 🇵🇹</th></tr>
${themeRows}
</table>
<p style="color:#64748b;font-size:.85rem">— / ${LQ.t("home.s1")}: EN ${LQ.learnedCount("en")} · ES ${LQ.learnedCount("es")} · PT ${LQ.learnedCount("pt")}</p>
<h2>⏱️ ${LQ.t("pr.exams")}</h2>
${s.exams.length ? `<table><tr><th>${LQ.t("pr.date")}</th><th>${LQ.t("pr.acc")}</th><th>${LQ.t("pr.time")}</th><th>${LQ.t("pr.grade")}</th></tr>
${s.exams.map(e => `<tr><td>${new Date(e.date).toLocaleDateString(s.uiLang)}</td><td>${e.acc}%</td><td>${LQ.fmtTime(e.time)}</td><td>${e.grade}</td></tr>`).join("")}</table>` : "<p>—</p>"}
<h2>✅ ${LQ.t("pr.learned")} (${LQ.langName(s.target)})</h2>
<p>${LQ.ALL.filter(w => LQ.isLearned(w.id, s.target)).map(w => w[s.target].replace(/\([^)]*\)/g,"").trim()).join(" · ") || "—"}</p>
<div class="foot">🔮 QUIVOX · ${LQ.t("footer.madeby")}: <b>LEO USTIMOV</b></div>
</body></html>`;
  LQ.download("QUIVOX-Report.html", html);
  LQ.toast("📄 ✓", true);
}

/* ================= МАГАЗИН ================= */
const SHOP = {
  avatars: [
    { id:"🐲", price:200, k:"sh.av1" },
    { id:"🦉", price:150, k:"sh.av2" },
    { id:"🐺", price:150, k:"sh.av3" },
    { id:"🤖", price:250, k:"sh.av4" },
    { id:"👽", price:300, k:"sh.av5" },
    { id:"🥷", price:300, k:"sh.av6" },
  ],
  skins: [
    { id:"ocean",    price:150, c:"linear-gradient(135deg,#06b6d4,#818cf8)" },
    { id:"sunset",   price:150, c:"linear-gradient(135deg,#f97316,#f43f5e)" },
    { id:"emerald",  price:150, c:"linear-gradient(135deg,#10b981,#a3e635)" },
    { id:"cyberpunk",price:250, c:"linear-gradient(135deg,#ec4899,#22d3ee)" },
    { id:"gold",     price:300, c:"linear-gradient(135deg,#f59e0b,#fde047)" },
  ],
  stuff: [
    { id:"hints5", icon:"💡", price:100 },
    { id:"shield", icon:"🛡",  price:200 },
  ]
};

LQ.pages.shop = () => {
  const s = LQ.state;
  const buyBtn = (ok, label, dis) => `<button class="btn ${ok?"primary":""}" ${dis?"disabled":""}>${label}</button>`;

  LQ.qs("#page-shop").innerHTML = `
    <h2 class="section-title">🛒 ${LQ.t("sh.title")} <small>${LQ.t("sh.sub")}</small></h2>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
      <div style="font-size:1.1rem;font-weight:800">🪙 <span class="glow-text" style="font-size:1.6rem">${s.coins}</span></div>
      <div class="muted" style="font-size:.85rem">💡 ${LQ.t("sh.hints")}: <b>${s.owned.hints}</b> · 🛡 ${LQ.t("sh.shield")}: <b>${s.stats.shield?"✓":"—"}</b> · ⚡ ×2: <b>${(s.stats.boostUntil||0) > Date.now() ? LQ.fmtTime(Math.ceil((s.stats.boostUntil-Date.now())/1000)) : "—"}</b></div>
    </div>

    <h3 class="section-title">😎 ${LQ.t("sh.avatars")}</h3>
    <div class="shop-grid" id="shopAvatars"></div>

    <h3 class="section-title">🎨 ${LQ.t("sh.skins")}</h3>
    <div class="shop-grid" id="shopSkins"></div>

    <h3 class="section-title">🧰 ${LQ.t("sh.stuff")}</h3>
    <div class="shop-grid">
      <div class="card shop-item" data-stuff="hints5">
        <div class="si">💡</div><h4>${LQ.t("sh.hints")}</h4><p>${LQ.t("sh.hintsD")}</p>
        <div class="price">100 🪙</div><div style="margin-top:10px" data-zone></div>
      </div>
      <div class="card shop-item" data-stuff="shield">
        <div class="si">🛡</div><h4>${LQ.t("sh.shield")}</h4><p>${LQ.t("sh.shieldD")}</p>
        <div class="price">200 🪙</div><div style="margin-top:10px" data-zone></div>
      </div>
      <div class="card shop-item" data-stuff="chest">
        <div class="si">🎁</div><h4>${LQ.t("sh.chest")}</h4><p>${LQ.t("sh.chestD")}</p>
        <div class="price">100 🪙</div><div style="margin-top:10px" data-zone></div>
      </div>
      <div class="card shop-item" data-stuff="boost">
        <div class="si">⚡</div><h4>${LQ.t("sh.boost")}</h4><p>${LQ.t("sh.boostD")}</p>
        <div class="price">400 🪙</div><div style="margin-top:10px" data-zone></div>
      </div>
      <div class="card shop-item" data-stuff="frame">
        <div class="si">🖼️</div><h4>${LQ.t("sh.frame")}</h4><p>${LQ.t("sh.frameD")}</p>
        <div class="price">350 🪙</div><div style="margin-top:10px" data-zone></div>
      </div>
    </div>`;

  // аватары
  const avBox = LQ.qs("#shopAvatars");
  SHOP.avatars.forEach(a => {
    const owned = s.owned.avatars.includes(a.id);
    const item = document.createElement("div");
    item.className = "card shop-item hoverable" + (owned ? " owned" : "");
    item.innerHTML = `${owned?'<span class="owned-tag">'+LQ.t("sh.owned")+'</span>':""}
      <div class="si">${a.id}</div><h4>${LQ.t(a.k)}</h4>
      ${owned ? `<p>${LQ.t("prf.avatar")}</p>` : `<div class="price">${a.price} 🪙</div>`}
      <div style="margin-top:10px"></div>`;
    const btn = document.createElement("button");
    btn.className = "btn" + (owned ? "" : " primary");
    btn.textContent = owned ? LQ.t("sh.apply") : LQ.t("sh.buy");
    if (!owned && s.coins < a.price) btn.disabled = true;
    btn.onclick = () => {
      if (owned) { s.user.avatar = a.id; LQ.save(); LQ.syncChip(); LQ.toast(a.id); LQ.fx("coin"); LQ.pages.shop(); return; }
      if (!spend(a.price)) return;
      s.owned.avatars.push(a.id); s.stats.bought = true; s.user.avatar = a.id;
      LQ.save(); LQ.syncChip(); LQ.toast("🎉 " + LQ.t("sh.bought",{item:a.id}), true); LQ.fx("level"); LQ.pages.shop();
    };
    item.lastElementChild.appendChild(btn);
    avBox.appendChild(item);
  });

  // темы оформления
  const skBox = LQ.qs("#shopSkins");
  SHOP.skins.forEach(sk => {
    const owned = s.owned.skins.includes(sk.id);
    const active = s.theme === sk.id;
    const item = document.createElement("div");
    item.className = "card shop-item hoverable" + (owned ? " owned" : "");
    item.innerHTML = `${active?'<span class="owned-tag">'+LQ.t("sh.applied")+" ✓</span>": owned?'<span class="owned-tag">'+LQ.t("sh.owned")+'</span>':""}
      <div class="skin-preview" style="background:${sk.c}"></div>
      <h4 style="margin-top:10px">${LQ.t("sh.skin."+sk.id)}</h4>
      ${owned ? "" : `<div class="price" style="margin-top:8px">${sk.price} 🪙</div>`}
      <div style="margin-top:10px"></div>`;
    const btn = document.createElement("button");
    btn.className = "btn" + (owned ? "" : " primary");
    btn.textContent = active ? LQ.t("sh.applied") : owned ? LQ.t("sh.apply") : LQ.t("sh.buy");
    btn.disabled = active || (!owned && s.coins < sk.price);
    btn.onclick = () => {
      if (!owned) { if (!spend(sk.price)) return; s.owned.skins.push(sk.id); s.stats.bought = true; LQ.toast("🎉 " + LQ.t("sh.bought",{item:LQ.t("sh.skin."+sk.id)}), true); }
      LQ.applySkin(sk.id); LQ.fx("level"); LQ.pages.shop();
    };
    item.lastElementChild.appendChild(btn);
    skBox.appendChild(item);
  });

  // расходники
  LQ.qsa("[data-stuff]").forEach(card => {
    const id = card.dataset.stuff, zone = LQ.qs("[data-zone]", card);
    const btn = document.createElement("button");
    btn.className = "btn primary";
    if (id === "hints5") {
      btn.textContent = LQ.t("sh.buy"); btn.disabled = s.coins < 100;
      btn.onclick = () => { if (!spend(100)) return; s.owned.hints += 5; LQ.toast("💡 +5", true); LQ.fx("coin"); LQ.pages.shop(); };
    } else if (id === "shield") {
      btn.textContent = s.stats.shield ? LQ.t("sh.owned") : LQ.t("sh.buy");
      btn.disabled = s.stats.shield || s.coins < 200;
      btn.onclick = () => { if (!spend(200)) return; s.stats.shield = true; LQ.save(); LQ.toast("🛡 ✓", true); LQ.fx("coin"); LQ.pages.shop(); };
    } else if (id === "chest") {
      // сундук удачи: случайный выигрыш 20–400 монет
      btn.textContent = LQ.t("sh.buy"); btn.disabled = s.coins < 100;
      btn.onclick = () => {
        if (!spend(100)) return;
        const win = [20,30,40,50,80,120,200,300,400][Math.random()*9|0];
        LQ.state.coins += win; LQ.state.stats.earned += win; LQ.save(); LQ.syncChip();
        LQ.confetti(); LQ.fx("coin"); LQ.toast("🎁 " + LQ.t("sh.chestWin",{n:win}), true); LQ.pages.shop();
      };
    } else if (id === "boost") {
      // XP-буст ×2 на 1 час
      const left = (s.stats.boostUntil || 0) - Date.now();
      if (left > 0) {
        btn.textContent = "⚡ ×2 · " + LQ.t("sh.activeT",{ t: LQ.fmtTime(Math.ceil(left/1000)) });
        btn.disabled = true;
      } else {
        btn.textContent = LQ.t("sh.buy"); btn.disabled = s.coins < 400;
        btn.onclick = () => { if (!spend(400)) return; s.stats.boostUntil = Date.now() + 3600e3; LQ.save(); LQ.confetti(); LQ.fx("level"); LQ.toast("⚡ ×2 ✓", true); LQ.pages.shop(); };
      }
    } else if (id === "frame") {
      // золотая рамка аватара (косметика)
      btn.textContent = s.owned.frame ? LQ.t("sh.owned") : LQ.t("sh.buy");
      btn.disabled = s.owned.frame || s.coins < 350;
      btn.onclick = () => { if (!spend(350)) return; s.owned.frame = true; LQ.save(); LQ.syncChip(); LQ.confetti(); LQ.toast("🖼️ ✨", true); LQ.pages.shop(); };
    }
    zone.appendChild(btn);
  });

  function spend(n) {
    if (LQ.state.coins < n) { LQ.toast(LQ.t("sh.notEnough")); LQ.fx("bad"); return false; }
    LQ.state.coins -= n; LQ.state.stats.bought = true; LQ.save(); LQ.syncChip(); LQ.checkAch();
    return true;
  }
};

/* ================= ПРОФИЛЬ ================= */
LQ.openProfile = () => {
  const s = LQ.state;
  const avs = s.owned.avatars.map(a => `<button class="prof-av ${a===s.user.avatar?"on":""}" data-av="${a}">${a}</button>`).join("");
  LQ.modal({
    title: `👤 ${LQ.t("prf.title")}`,
    html: `
      <div class="prof-row"><label>${LQ.t("prf.name")}</label><input id="pfName" class="input" maxlength="20" value="${LQ.esc(s.user.name)}"></div>
      <div class="prof-row"><label>${LQ.t("prf.avatar")}</label><div class="prof-avs">${avs}</div></div>
      <div class="prof-row"><label>${LQ.t("prf.lang")}</label>
        <select id="pfTarget" class="input">${["en","es","pt","ru","all"].map(l => `<option value="${l}" ${l===s.target?"selected":""}>${LQ.langLabel(l)}</option>`).join("")}</select>
      </div>
      <div class="prof-row">
        <label>🔊 TTS / FX</label>
        <button class="btn" id="pfSound">${s.sound ? "ON 🔊" : "OFF 🔇"}</button>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
        <button class="btn" id="pfExport">${LQ.t("prf.export")}</button>
        <button class="btn" id="pfImportBtn">${LQ.t("prf.import")}</button>
        <input type="file" id="pfImport" accept=".json" class="hidden">
        <button class="btn primary" id="pfShare">${LQ.t("share.gen")}</button>
        <button class="btn danger" id="pfReset">${LQ.t("prf.reset")}</button>
      </div>`,
    actions: [
      { label: LQ.t("prf.save"), cls: "primary", fn: () => {
          const name = LQ.qs("#pfName").value.trim();
          if (name) s.user.name = LQ.esc(name);
          s.target = LQ.qs("#pfTarget").value;
          const av = LQ.qs(".prof-av.on");
          if (av) s.user.avatar = av.dataset.av;
          LQ.save(); LQ.syncChip(); LQ.toast(LQ.t("prf.saved")); LQ.fx("good");
        } },
      { label: LQ.t("misc.close") }
    ]
  });
  LQ.qsa(".prof-av").forEach(b => b.onclick = () => { LQ.qsa(".prof-av").forEach(x => x.classList.toggle("on", x===b)); });
  LQ.qs("#pfSound").onclick = e => { s.sound = !s.sound; LQ.save(); e.target.textContent = s.sound ? "ON 🔊" : "OFF 🔇"; if (!s.sound && "speechSynthesis" in window) speechSynthesis.cancel(); };
  LQ.qs("#pfExport").onclick = LQ.exportData;
  const imp = LQ.qs("#pfImport");
  LQ.qs("#pfImportBtn").onclick = () => imp.click();
  imp.onchange = () => imp.files[0] && LQ.importData(imp.files[0]);
  LQ.qs("#pfShare").onclick = shareProfile;
  LQ.qs("#pfReset").onclick = () => {
    LQ.modal({ title: "⚠️", html: `<p>${LQ.t("prf.resetWarn")}</p>`, actions: [
      { label: LQ.t("misc.yes"), cls: "danger", fn: () => { Store.wipe(); location.reload(); } },
      { label: LQ.t("misc.cancel") }
    ]});
  };
};


/* ================= ЭКСПОРТ / ИМПОРТ (переиспользуем) ================= */
LQ.exportData = () => {
  const blob = new Blob([JSON.stringify(LQ.state, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = "quivox-backup.json"; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  LQ.toast("💾 ✓");
};
LQ.importData = f => {
  const r = new FileReader();
  r.onload = () => { try {
      const data = JSON.parse(r.result);
      if (!data.user || !data.stats) throw 0;
      LQ.state = { ...LQ.defaults(), ...data };
      LQ.save(); LQ.toast(LQ.t("prf.imported"));
      setTimeout(() => location.reload(), 600);
    } catch(e){ LQ.toast(LQ.t("prf.importBad")); } };
  r.readAsText(f);
};

/* ================= ССЫЛКА НА ПРОФИЛЬ ================= */
function shareProfile() {
  const s = LQ.state, L = LQ.level();
  const data = {
    n: s.user.name, av: s.user.avatar, lv: L.lvl,
    xp: s.xp, c: s.coins, st: s.stats.streak.n, t: s.stats.tests,
    ex: s.stats.exams, bt: Math.round((s.stats.bestTest || 0) * 100),
    lw: ["en","es","pt"].reduce((a,l) => a + LQ.learnedCount(l), 0),
    ach: s.ach.length
  };
  const base = location.protocol === "file:"
    ? location.href.split("?")[0]
    : location.origin + location.pathname;
  const url = base + "?p=" + btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  try { navigator.clipboard.writeText(url); } catch(e){}
  LQ.modal({
    title: "🔗 " + LQ.t("share.gen"),
    html: `<p style="margin-bottom:12px;font-weight:700">${LQ.t("share.copied")}</p>
           <input class="input" readonly value="${url}" onclick="this.select()" style="font-size:.72rem;direction:ltr;text-align:left">
           <p class="muted" style="font-size:.72rem;margin-top:10px">${LQ.t("share.note")}</p>`,
    actions: [{ label: LQ.t("misc.ok"), cls: "primary" }]
  });
}

/* ---- просмотр чужого профиля по ссылке (?p=...) ---- */
LQ.showShared = (code, onClose) => {
  let p = null;
  try { p = JSON.parse(decodeURIComponent(escape(atob(code)))); } catch(e){}
  if (!p || !p.n) { onClose && onClose(); return; }
  const my = LQ.state.user ? {
    lv: LQ.level().lvl, xp: LQ.state.xp, c: LQ.state.coins, st: LQ.state.stats.streak.n,
    t: LQ.state.stats.tests, ex: LQ.state.stats.exams,
    bt: Math.round((LQ.state.stats.bestTest || 0) * 100),
    lw: ["en","es","pt"].reduce((a,l) => a + LQ.learnedCount(l), 0),
    ach: LQ.state.ach.length
  } : null;
  const rows = [
    ["🎚 " + LQ.t("share.lvl"), p.lv, my?.lv],
    ["✨ XP", p.xp, my?.xp],
    ["🪙 " + LQ.t("share.coins"), p.c, my?.c],
    ["🔥 " + LQ.t("home.streak"), p.st, my?.st],
    ["📚 " + LQ.t("home.s1"), p.lw, my?.lw],
    ["🎯 " + LQ.t("home.s2"), p.t, my?.t],
    ["⏱️ " + LQ.t("nav.exam"), p.ex, my?.ex],
    ["💯 " + LQ.t("home.s3"), p.bt || 0, my?.bt],
    ["🏅 " + LQ.t("pr.ach"), p.ach || 0, my?.ach],
  ];
  const cell = (v, win) => `<span><b class="${win ? "win" : ""}">${v}${win ? " 🔥" : ""}</b></span>`;
  const ov = document.createElement("div");
  ov.className = "overlay";
  ov.innerHTML = `<div class="modal-card" style="text-align:center">
    <div style="font-size:3.6rem;animation:bounceIn .6s">${LQ.esc(p.av || "🦊")}</div>
    <h2 style="justify-content:center">${LQ.esc(p.n)}</h2>
    <div class="lvl-name" style="font-size:.95rem;margin:6px 0 4px">Lv ${p.lv} · ${LQ.t("lvl." + Math.min(p.lv || 1, 10))}</div>
    <p class="muted" style="font-size:.8rem;margin-bottom:14px">${LQ.t("share.sub")}</p>
    ${my ? `<div class="vs-head"><span>${LQ.t("share.vs")}</span><span>${LQ.esc(p.n)}</span><span>${LQ.t("share.you")}</span></div>` : ""}
    ${rows.map(([label, pv, mv]) => {
      if (mv === undefined) return `<div class="vs-row" style="grid-template-columns:1fr auto"><span>${label}</span>${cell(pv, false)}</div>`;
      return `<div class="vs-row"><span>${label}</span>${cell(pv, (+pv) > (+mv))}${cell(mv, (+mv) > (+pv))}</div>`;
    }).join("")}
    <button class="btn primary big" id="shareClose" style="margin-top:18px;width:100%">OK</button>
  </div>`;
  document.getElementById("modalRoot").appendChild(ov);
  LQ.confetti(); LQ.fx("level");
  const close = () => {
    ov.remove();
    try { history.replaceState({}, "", location.pathname); } catch(e){}
    onClose && onClose();
  };
  ov.querySelector("#shareClose").onclick = close;
  ov.addEventListener("click", e => { if (e.target === ov) close(); });
};
