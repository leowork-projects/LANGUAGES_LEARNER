/* =====================================================
   QUIVOX — ГЛАВНАЯ + УЧИТЬ (карточки) + ПАНЕЛЬ СЛОВ
   ===================================================== */
"use strict";

/* ================= ГЛАВНАЯ ================= */
LQ.pages.home = () => {
  const s = LQ.state, L = LQ.level();
  const d = LQ.daily();
  const goalPct = Math.min(100, Math.round(d.c / LQ.GOAL * 100));
  const quote = LQ.t("q." + (new Date().getDate() % 5 + 1));
  const learned = LQ.learnedTotal();
  const bestAcc = s.stats.bestTest ? Math.round(s.stats.bestTest * 100) : 0;
  const C = 2 * Math.PI * 34; // длина окружности кольца уровня

  LQ.qs("#page-home").innerHTML = `
  <div class="hero">
    <div class="card hero-card">
      <h1>⚡ ${LQ.t("home.hi", { name: s.user.name })}</h1>
      <p class="hero-sub">${LQ.t("home.ready")}</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="btn primary glow" data-go="learn">🃏 ${LQ.t("nav.learn")}</button>
        <button class="btn" data-go="tests">🎯 ${LQ.t("nav.tests")}</button>
        <button class="btn" data-go="exam">⏱️ ${LQ.t("nav.exam")}</button>
      </div>
      <div class="hero-quote">${quote}</div>
      <div class="goal-wrap">
        <div class="goal-head"><span>🎯 ${LQ.t("home.goal")} — ${LQ.t("home.goalT",{n:LQ.GOAL})}</span><span>${d.c}/${LQ.GOAL}</span></div>
        <div class="progress-track"><div class="progress-bar" style="width:${goalPct}%"></div></div>
      </div>
    </div>
    <div class="card" style="display:flex;flex-direction:column;align-items:center;justify-content:center">
      <div class="lvl-badge" style="position:static">
        <div class="lvl-ring">
          <svg width="86" height="86" viewBox="0 0 86 86">
            <defs><linearGradient id="lvlGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="var(--accent)"/><stop offset="100%" stop-color="var(--accent2)"/>
            </linearGradient></defs>
            <circle class="track" cx="43" cy="43" r="34" stroke-width="8" fill="none"/>
            <circle class="bar" cx="43" cy="43" r="34" stroke-width="8" fill="none"
              stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - L.pct/100)}"/>
          </svg>
          <div class="lvl-num">${L.lvl}<small>LVL</small></div>
        </div>
        <div class="lvl-name">${L.name}</div>
        ${L.next ? `<div class="muted" style="font-size:.72rem">${s.xp} XP · ${LQ.t("home.toNext",{n:L.lvl+1})}</div>` : ""}
      </div>
      <div style="margin-top:10px;text-align:center">
        <span style="font-size:1.6rem">🔥</span>
        <b style="font-size:1.2rem">${s.stats.streak.n}</b>
        <span class="muted" style="font-size:.8rem">${LQ.t("home.streak")}</span>
      </div>
    </div>
  </div>

  <div class="stat-cards">
    <div class="card stat-card"><span class="ic">📚</span><div class="v">${learned}</div><div class="l">${LQ.t("home.s1")}</div></div>
    <div class="card stat-card"><span class="ic">🎯</span><div class="v">${s.stats.tests}</div><div class="l">${LQ.t("home.s2")}</div></div>
    <div class="card stat-card"><span class="ic">💯</span><div class="v">${bestAcc}%</div><div class="l">${LQ.t("home.s3")}</div></div>
    <div class="card stat-card"><span class="ic">✨</span><div class="v">${s.xp}</div><div class="l">${LQ.t("home.s4")}</div></div>
  </div>

  <h2 class="section-title">🚀 ${LQ.t("home.quick")}</h2>
  <div class="quick-grid">
    ${[["learn","🃏","q1"],["tests","🎯","q2"],["exam","⏱️","q3"],["shop","🛒","q4"]].map(([p,ic,k]) => `
      <div class="card hoverable q-card" data-go="${p}">
        <span class="qi">${ic}</span><h3>${LQ.t("home."+k+"t")}</h3><p>${LQ.t("home."+k+"d")}</p>
        <span class="arrow">→</span>
      </div>`).join("")}
  </div>`;

  LQ.qsa("#page-home [data-go]").forEach(b => b.addEventListener("click", () => LQ.go(b.dataset.go)));
};

/* ================= УЧИТЬ: КАРТОЧКИ ================= */
let cards = { pool: [], i: 0, flipped: false };

LQ.pages.learn = () => { cards = { pool: [], i: 0, flipped: false }; renderLearnMenu(); };

function renderLearnMenu() {
  const s = LQ.state;
  LQ.qs("#page-learn").innerHTML = `
    <h2 class="section-title">🃏 ${LQ.t("learn.title")}</h2>
    <div class="card">
      <div class="setup-label">${LQ.t("learn.selTheme")}</div>
      <div class="pill-row" id="learnThemes"></div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px">
        <span class="setup-label" style="margin:0">${LQ.t("t.from")}</span>
        <select id="learnFrom" class="input"></select>
        <span class="setup-label" style="margin:0">${LQ.t("t.to")}</span>
        <select id="learnTo" class="input"></select>
      </div>
    </div>`;
  // собираем список тем
  const row = LQ.qs("#learnThemes");
  const addPill = (id, icon, name, n) => {
    const b = document.createElement("button");
    b.className = "pill"; b.innerHTML = `${icon} ${LQ.esc(name)} <span class="muted">· ${n} ${LQ.t("wp.words")}</span>`;
    b.onclick = () => startCards(id);
    row.appendChild(b);
  };
  addPill("*", "🎲", LQ.t("learn.all"), LQ.ALL.length);
  WORDS_DB.themes.forEach(th => addPill(th.id, th.icon, th.title[LQ.state.uiLang] || th.title.ru, LQ.themeWords(th.id).length));

  // направление: с любого языка на любой (или 🌍 все сразу)
  const langs = ["ru","en","es","pt"];
  const from = LQ.qs("#learnFrom"), to = LQ.qs("#learnTo");
  from.innerHTML = langs.map(l => `<option value="${l}" ${l===s.base?"selected":""}>${LQ.langLabel(l)}</option>`).join("");
  to.innerHTML = `<option value="all" ${s.target==="all"?"selected":""}>${LQ.langLabel("all")}</option>` +
    langs.map(l => `<option value="${l}" ${l===s.target?"selected":""}>${LQ.langLabel(l)}</option>`).join("");
  const sync = () => {
    if (from.value === to.value) to.value = "all";
    LQ.state.base = from.value; LQ.state.target = to.value; LQ.save();
  };
  from.onchange = sync; to.onchange = sync;
}

function startCards(themeId) {
  cards.pool = LQ.shuffle(themeId === "*" ? LQ.ALL : LQ.themeWords(themeId));
  cards.i = 0; cards.flipped = false;
  renderCard();
}

function renderCard() {
  const w = cards.pool[cards.i], s = LQ.state;
  const th = LQ.themeById(w.tid);
  const front = w[s.base].replace(/\([^)]*\)/g,"").trim();
  // языки перевода карточки: all → все иностранные, ru → базовый иностранный
  const effLangs = s.target === "all" ? ["en","es","pt"].filter(l => l !== s.base)
                  : s.target === "ru" ? (s.base === "ru" ? ["en"] : [s.base])
                  : [s.target];
  const backAll = effLangs.length === 1
    ? `<div class="flash-word" style="color:var(--accent2)">${LQ.esc(w[effLangs[0]])}</div>
       <button class="speak-big" id="cardSpeak" title="${LQ.t("learn.listen")}">🔊</button>`
    : `<div style="display:flex;flex-direction:column;gap:8px;align-items:stretch;width:100%;max-width:340px">` +
      effLangs.map(l => `<div class="card-tr"><b>${LQ.FLAG[l]}</b> <span>${LQ.esc(w[l])}</span><span class="wp-speak" data-l="${l}" style="margin-left:auto">🔊</span></div>`).join("") + `</div>`;
  const m = effLangs.length === 1 ? LQ.mast(w.id, effLangs[0])
            : Math.round(effLangs.reduce((a,l) => a + LQ.mast(w.id,l), 0) / effLangs.length);
  const mastered = cards.pool.filter(x => effLangs.length === 1
    ? LQ.mast(x.id, effLangs[0]) >= 80
    : effLangs.every(l => LQ.mast(x.id,l) >= 80)).length;

  LQ.qs("#page-learn").innerHTML = `
    <button class="btn" id="cardsBack" style="margin-bottom:14px">${LQ.t("learn.back")}</button>
    <div class="flash-stage">
      <div class="flash-card ${cards.flipped ? "flipped" : ""}" id="flashCard">
        <div class="flash-face">
          <div class="flash-theme">${th.icon} ${th.title[s.uiLang] || th.title.ru}</div>
          <div class="flash-word">${LQ.esc(front)}</div>
          <div class="flash-hint">☝️ ${LQ.t("learn.flip")}</div>
        </div>
        <div class="flash-face back">
          ${backAll}
          <div class="muted" style="font-size:.75rem">${LQ.t("learn.mastered")}: ${m}%</div>
        </div>
      </div>
      <div class="card-counter">${LQ.t("learn.count", { a: cards.i+1, b: cards.pool.length })} · ${LQ.t("learn.mastered")} ${mastered}/${cards.pool.length}</div>
      <div class="flash-actions">
        <button class="btn danger" id="cardDunno">↻ ${LQ.t("learn.dunno")}</button>
        <button class="btn" id="cardFlip">🔄</button>
        <button class="btn good" id="cardKnow">✓ ${LQ.t("learn.know")}</button>
      </div>
    </div>`;

  const flip = () => { cards.flipped = !cards.flipped; LQ.qs("#flashCard").classList.toggle("flipped", cards.flipped); };
  LQ.qs("#flashCard").onclick = e => { if (!e.target.closest(".speak-big") && !e.target.closest(".wp-speak")) flip(); };
  LQ.qs("#cardFlip").onclick = flip;
  const cs = LQ.qs("#cardSpeak");
  if (cs) cs.onclick = () => LQ.speak(w[effLangs[0]], effLangs[0]);
  LQ.qsa("#page-learn .wp-speak").forEach(sp => sp.onclick = e => { e.stopPropagation(); LQ.speak(w[sp.dataset.l], sp.dataset.l); });
  LQ.qs("#cardsBack").onclick = () => LQ.pages.learn();

  const next = () => { cards.i = (cards.i + 1) % cards.pool.length; cards.flipped = false; renderCard(); };
  LQ.qs("#cardKnow").onclick = () => {
    effLangs.forEach(l => LQ.bumpMast(w.id, l, 10)); LQ.addXp(2); LQ.fx("good"); LQ.onCorrectCard(w); next();
  };
  LQ.qs("#cardDunno").onclick = () => { effLangs.forEach(l => LQ.bumpMast(w.id, l, -8)); LQ.fx("bad"); next(); };
}
// лёгкая награда за карточки (без монет, чтобы не фармили)
LQ.onCorrectCard = w => {
  LQ.state.stats.correct++; LQ.touchStreak(); const d = LQ.daily(); d.c++;
  if (d.c >= LQ.GOAL && !d.goal) { d.goal = true; LQ.toast("🎯 " + LQ.t("home.goalDone",{n:LQ.GOAL_REWARD}), true); LQ.confetti(); LQ.addCoins(LQ.GOAL_REWARD); }
  LQ.save(); LQ.checkAch();
};

/* ================= ПАНЕЛЬ СЛОВ (как Excel) ================= */
LQ._wpTheme = "*"; // фильтр темы панели
LQ.renderWordsPanel = () => {
  const s = LQ.state, q = LQ.clean(LQ.qs("#wpSearch").value || "");
  // пилюли тем
  const box = LQ.qs("#wpThemes"); box.innerHTML = "";
  const mkPill = (id, icon, name) => {
    const b = document.createElement("button");
    b.className = "wp-pill" + (LQ._wpTheme === id ? " on" : "");
    b.textContent = `${icon} ${name}`;
    b.onclick = () => { LQ._wpTheme = id; LQ.renderWordsPanel(); };
    box.appendChild(b);
  };
  mkPill("*", "📚", LQ.t("wp.all"));
  WORDS_DB.themes.forEach(th => mkPill(th.id, th.icon, th.title[s.uiLang] || th.title.ru));

  // строки таблицы
  const langs = ["ru","en","es","pt"];
  const flags = LQ.FLAG;
  let rows = LQ._wpTheme === "*" ? LQ.ALL : LQ.themeWords(LQ._wpTheme);
  if (q) rows = rows.filter(w => langs.some(l => LQ.clean(w[l]).includes(q)));

  const tbl = LQ.qs("#wpTable");
  tbl.innerHTML = `<thead><tr><th>#</th>${langs.map(l => `<th>${flags[l]} ${l.toUpperCase()}</th>`).join("")}</tr></thead>
    <tbody>${rows.length ? rows.map((w,i) => {
      const learned = LQ.targetLangs().some(l => LQ.isLearned(w.id, l));
      return `<tr class="${learned ? "learned" : ""}">
        <td class="muted">${i+1}</td>
        ${langs.map(l => `<td>${LQ.esc(w[l].replace(/\([^)]*\)/g,"").trim())}
          <span class="wp-speak" data-say="${l}" data-id="${w.id}" title="🔊">🔊</span>
          ${(LQ.targetLangs().includes(l) && LQ.isLearned(w.id, l)) ? '<span class="wp-badge">✓</span>' : ""}</td>`).join("")}
      </tr>`; }).join("")
    : `<tr><td colspan="5" class="muted" style="text-align:center;padding:22px">${LQ.t("wp.empty")}</td></tr>`}</tbody>`;

  LQ.qsa("#wpTable .wp-speak").forEach(sp =>
    sp.addEventListener("click", e => {
      e.stopPropagation();
      const w = LQ.byId(sp.dataset.id);
      LQ.speak(w[sp.dataset.say], sp.dataset.say);
    }));
};
