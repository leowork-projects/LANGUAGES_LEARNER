/* =====================================================
   QUIVOX — ЯДРО (состояние, хранилище, утилиты)
   ===================================================== */
"use strict";
const LQ = {
  pages: {},          // рендер-функции страниц (заполняют pages.js / tests.js / meta.js)
  current: "home",    // текущая страница
  state: null,
  AV_FREE: ["🦊","🐼","🦁","🐸","🐰"],           // 5 стартовых аватаров
  XP_LEVELS: [0,100,250,500,900,1400,2100,3000,4200,6000], // пороги уровней (10 ур.)
  GOAL: 20,           // дневная цель (правильных ответов)
  GOAL_REWARD: 50,
};

/* ---------- ХРАНИЛИЩЕ (localStorage + fallback) ---------- */
const Store = {
  KEY: "quivox_v1", LEGACY: "quizzard_v1", mem: null, ok: true,
  get() {
    try {
      let v = null;
      for (const k of [this.KEY, this.LEGACY, "vocano_v1", "lingoquest_v1"]) { v = JSON.parse(localStorage.getItem(k)); if (v) break; }
      return v;
    }
    catch(e){ this.ok = false; return this.mem; }
  },
  set(v) {
    try { localStorage.setItem(this.KEY, JSON.stringify(v)); }
    catch(e){ this.ok = false; this.mem = v; }
  },
  wipe(){ try{ localStorage.removeItem(this.KEY); }catch(e){} this.mem = null; }
};

LQ.defaults = () => ({
  user: null,                       // {name, avatar}
  uiLang: "ru", base: "ru", target: "en",
  theme: "violet", sound: true,
  coins: 0, xp: 0,
  mast: {},                         // wordId -> {en:0..100, es:.., pt:..}
  mist: {},                         // "wordId:lang" -> {n, last}
  stats: { tests:0, exams:0, correct:0, total:0, bestTest:0, bestExam:null,
           daily:{}, streak:{n:0,last:null}, shield:false, earned:0, boostUntil:0 },
  ach: [],
  owned: { avatars:[...LQ.AV_FREE], skins:["violet"], hints:0, frame:false },
  exams: []                         // {date, acc, time, grade}
});

LQ.save = () => Store.set(LQ.state);

/* ---------- БАЗА СЛОВ: id и плоский список ---------- */
WORDS_DB.themes.filter(th => th.words).forEach(th => th.words.forEach((w,i) => { w.tid = th.id; w.id = th.id + "_" + (i+1); }));
LQ.ALL = WORDS_DB.themes.filter(th => th.words).flatMap(t => t.words); // объединённые темы (combine) не дублируем
LQ.byId = id => LQ.ALL.find(w => w.id === id);
LQ.themeById = id => WORDS_DB.themes.find(t => t.id === id);
LQ.themeWords = id => { // тема может быть объединённой (combine: [ids])
  const th = LQ.themeById(id);
  if (!th) return [];
  return th.words ? th.words : th.combine.flatMap(cid => LQ.themeById(cid).words);
};

/* ---------- i18n ---------- */
LQ.t = (key, vars = {}) => {
  const pack = I18N[LQ.state?.uiLang] || I18N.ru;
  let s = pack[key] ?? I18N.ru[key] ?? key;
  Object.entries(vars).forEach(([k,v]) => s = s.replaceAll("{"+k+"}", v));
  return s;
};
LQ.langName = code => LQ.t("lang."+code);
LQ.FLAG = { ru:"🇷🇺", en:"🇺🇸", es:"🇲🇽", pt:"🇧🇷", all:"🌍" }; // флаги рядом с языками
// выбранные языки изучения ("all" → все три)
LQ.targetLangs = () => LQ.state.target === "all" ? ["en","es","pt"] : [LQ.state.target];
LQ.learnedTotal = () => LQ.targetLangs().reduce((a,l) => a + LQ.learnedCount(l), 0);
LQ.langLabel = code => LQ.FLAG[code] + " " + LQ.langName(code);

/* ---------- НОРМАЛИЗАЦИЯ И ПРОВЕРКА ОТВЕТОВ ----------
   Игнорируем регистр, акценты (ñ→n, á→a, ç→c...),
   спецзнаки и уточнения в скобках. */
LQ.clean = s => (s||"").toLowerCase().trim()
  .normalize("NFD").replace(/[\u0300-\u036f]/g,"")
  .replace(/\([^)]*\)/g," ")
  .replace(/[^a-zа-яё0-9\s-]/gi,"")
  .replace(/\s+/g," ").trim();

LQ.variants = s => (s||"").replace(/\([^)]*\)/g," ")
  .split(/\s*\/\s*/).map(LQ.clean).filter(Boolean);

LQ.checkAnswer = (input, dbStr) => {
  const v = LQ.clean(input);
  return v.length > 0 && LQ.variants(dbStr).includes(v);
};

/* ---------- ОЗВУЧКА (Web Speech API) ---------- */
LQ.VOICE_LANG = { ru:"ru-RU", en:"en-US", es:"es-MX", pt:"pt-BR" }; // озвучка под регион флага
LQ.speak = (text, lang) => {
  if (!LQ.state?.sound || !("speechSynthesis" in window)) return;
  try {
    speechSynthesis.cancel();
    const clean = text.split(" / ")[0].replace(/\([^)]*\)/g,"").trim();
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = LQ.VOICE_LANG[lang] || "en-US"; u.rate = .92;
    const v = speechSynthesis.getVoices().find(v => v.lang === u.lang)
           || speechSynthesis.getVoices().find(v => v.lang.startsWith(u.lang.slice(0,2)));
    if (v) u.voice = v;
    speechSynthesis.speak(u);
  } catch(e){}
};
if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = () => {}; // прогрев голосов

/* ---------- ЗВУКОВЫЕ ЭФФЕКТЫ (WebAudio) ---------- */
LQ._ac = null;
LQ.fx = type => {
  if (!LQ.state?.sound) return;
  try {
    LQ._ac = LQ._ac || new (window.AudioContext||window.webkitAudioContext)();
    const ac = LQ._ac, now = ac.currentTime;
    const notes = { good:[523,784], bad:[200,150], coin:[880,1320], level:[523,659,784,1047] }[type] || [440];
    notes.forEach((f,i) => {
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = type === "bad" ? "sawtooth" : "sine"; o.frequency.value = f;
      g.gain.setValueAtTime(.001, now + i*.09);
      g.gain.exponentialRampToValueAtTime(.12, now + i*.09 + .02);
      g.gain.exponentialRampToValueAtTime(.001, now + i*.09 + .25);
      o.connect(g).connect(ac.destination); o.start(now + i*.09); o.stop(now + i*.09 + .3);
    });
  } catch(e){}
};

/* ---------- УРОВНИ ---------- */
LQ.level = () => {
  const xp = LQ.state.xp; let l = 1;
  LQ.XP_LEVELS.forEach((need,i) => { if (xp >= need) l = i+1; });
  const next = LQ.XP_LEVELS[l]; const prev = LQ.XP_LEVELS[l-1];
  const pct = next ? Math.round((xp-prev)/(next-prev)*100) : 100;
  return { lvl:l, pct, next, name: LQ.t("lvl."+Math.min(l,10)) };
};

/* ---------- НАГРАДЫ ---------- */
let _achBusy = false;
LQ.addCoins = n => {
  if (n) { LQ.state.coins += n; if (n>0) LQ.state.stats.earned += n; }
  LQ.syncChip(); LQ.save(); LQ.checkAch();
};
LQ.addXp = n => {
  if (Date.now() < (LQ.state.stats.boostUntil || 0)) n *= 2; // XP-буст ×2 из магазина
  const before = LQ.level().lvl;
  LQ.state.xp += n;
  const after = LQ.level().lvl;
  LQ.save();
  if (after > before){ LQ.fx("level"); LQ.confetti(); LQ.toast(`🆙 Lv ${after} — ${LQ.t("lvl."+Math.min(after,10))}`, true); }
  LQ.syncChip();
};
LQ.fly = (text, color="#fbbf24") => {
  const anchor = document.getElementById("userChip") || document.body;
  const r = anchor.getBoundingClientRect();
  const s = document.createElement("span");
  s.className = "fly"; s.textContent = text; s.style.color = color;
  s.style.left = (r.left + r.width/2 - 14) + "px"; s.style.top = (r.bottom + 4) + "px";
  document.body.appendChild(s); setTimeout(() => s.remove(), 1000);
};

/* ---------- ДНИ / СТРИК / ЦЕЛЬ ---------- */
LQ.dayKey = (d=new Date()) =>
  d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
LQ.touchStreak = () => {
  const st = LQ.state.stats.streak, today = LQ.dayKey();
  if (st.last === today) return;
  const yest = LQ.dayKey(new Date(Date.now() - 864e5));
  if (st.last === yest) st.n++;
  else if (st.last && st.last < yest) {
    if (LQ.state.stats.shield){ LQ.state.stats.shield = false; st.n++; LQ.toast("🛡 " + LQ.t("sh.shield") + "!", true); }
    else st.n = 1;
  } else if (!st.last) st.n = 1; else st.n = 1;
  st.last = today; LQ.save(); LQ.checkAch();
};
LQ.daily = () => {
  const k = LQ.dayKey();
  if (!LQ.state.stats.daily[k]) LQ.state.stats.daily[k] = { c:0, x:0, goal:false };
  return LQ.state.stats.daily[k];
};

/* ---------- МАСТЕРСТВО СЛОВ ---------- */
LQ.mast = (id, lang) => LQ.state.mast[id]?.[lang] || 0;
LQ.bumpMast = (id, lang, delta) => {
  const m = LQ.state.mast[id] = LQ.state.mast[id] || { en:0, es:0, pt:0 };
  m[lang] = Math.max(0, Math.min(100, (m[lang]||0) + delta));
};
LQ.isLearned = (id, lang) => LQ.mast(id, lang) >= 80;
LQ.learnedCount = lang => LQ.ALL.filter(w => LQ.isLearned(w.id, lang)).length;
LQ.addMistake = (id, lang) => {
  const k = id + ":" + lang;
  LQ.state.mist[k] = LQ.state.mist[k] || { n:0 };
  LQ.state.mist[k].n++; LQ.state.mist[k].last = Date.now();
};
LQ.clearMistake = (id, lang) => {
  const k = id + ":" + lang;
  if (LQ.state.mist[k] && --LQ.state.mist[k].n <= 0) delete LQ.state.mist[k];
};
LQ.mistakeWords = lang =>
  Object.keys(LQ.state.mist).filter(k => k.endsWith(":"+lang)).map(k => LQ.byId(k.split(":")[0])).filter(Boolean);
LQ.mistakePool = () => [...new Set(LQ.targetLangs().flatMap(l => LQ.mistakeWords(l)))]; // ошибки по всем выбранным языкам

/* ---------- ОБЩИЙ ОБРАБОТЧИК ПРАВИЛЬНОГО ОТВЕТА ---------- */
LQ.onCorrect = (id, lang, mode, coins, xp) => {
  const gain = { write:20, choice:15, listen:15 }[mode] || 15;
  LQ.bumpMast(id, lang, gain);
  LQ.clearMistake(id, lang);
  LQ.state.stats.correct++;
  LQ.touchStreak();
  const d = LQ.daily(); d.c++; d.x += xp;
  if (d.c >= LQ.GOAL && !d.goal) {
    d.goal = true;
    LQ.toast("🎯 " + LQ.t("home.goalDone", { n: LQ.GOAL_REWARD }), true);
    LQ.confetti(); LQ.addCoins(LQ.GOAL_REWARD);
  }
  if (coins) LQ.addCoins(coins);
  if (xp) LQ.addXp(xp);
  LQ.save();
};

/* ---------- ДОСТИЖЕНИЯ ---------- */
LQ.ACH = [
  { id:"first_test", ic:"🎯", reward:25,  check: () => LQ.state.stats.tests >= 1 },
  { id:"first_exam", ic:"⏱️", reward:40,  check: () => LQ.state.stats.exams >= 1 },
  { id:"words10",    ic:"🔤", reward:30,  check: () => Math.max(...["en","es","pt"].map(LQ.learnedCount)) >= 10 },
  { id:"words25",    ic:"📚", reward:60,  check: () => Math.max(...["en","es","pt"].map(LQ.learnedCount)) >= 25 },
  { id:"words50",    ic:"🏆", reward:120, check: () => Math.max(...["en","es","pt"].map(LQ.learnedCount)) >= 50 },
  { id:"perfect",    ic:"💯", reward:50,  check: () => LQ.state.stats.bestTest === 1 && LQ.state.stats.tests >= 1 },
  { id:"examA",      ic:"🌟", reward:100, check: () => LQ.state.exams.some(e => e.acc >= 90) },
  { id:"streak3",    ic:"🔥", reward:30,  check: () => LQ.state.stats.streak.n >= 3 },
  { id:"streak7",    ic:"☄️", reward:70,  check: () => LQ.state.stats.streak.n >= 7 },
  { id:"rich",       ic:"💰", reward:80,  check: () => LQ.state.coins >= 500 },
  { id:"shopper",    ic:"🛍️", reward:25,  check: () => LQ.state.owned.skins.length > 1 || LQ.state.owned.avatars.length > LQ.AV_FREE.length || LQ.state.stats.bought },
  { id:"polyglot",   ic:"🌍", reward:100, check: () => ["en","es","pt"].every(l => LQ.learnedCount(l) >= 10) },
];
LQ.checkAch = () => {
  if (_achBusy || !LQ.state) return; _achBusy = true;
  LQ.ACH.forEach(a => {
    if (!LQ.state.ach.includes(a.id) && a.check()) {
      LQ.state.ach.push(a.id);
      LQ.toast(`${a.ic} ${LQ.t("ach."+a.id)} — ${LQ.t("ach.unlocked",{c:a.reward})}`, true);
      LQ.state.coins += a.reward; LQ.state.stats.earned += a.reward;
      LQ.confetti(); LQ.fx("coin");
    }
  });
  LQ.save(); LQ.syncChip(); _achBusy = false;
};

/* ---------- ТОСТЫ / МОДАЛКИ / КОНФЕТТИ ---------- */
LQ.toast = (html, gold=false) => {
  const box = document.getElementById("toasts");
  const t = document.createElement("div");
  t.className = "toast" + (gold ? " gold" : ""); t.innerHTML = html;
  box.appendChild(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 300); }, 3400);
};
LQ.modal = ({ title, html, actions = [] }) => {
  const root = document.getElementById("modalRoot");
  const ov = document.createElement("div");
  ov.className = "overlay";
  ov.innerHTML = `<div class="modal-card">
      <button class="icon-btn modal-x">✕</button>
      <h2>${title}</h2><div class="modal-body">${html}</div>
      <div class="modal-acts" style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap"></div>
    </div>`;
  const close = () => ov.remove();
  ov.addEventListener("click", e => { if (e.target === ov || e.target.closest(".modal-x")) close(); });
  const acts = ov.querySelector(".modal-acts");
  actions.forEach(a => {
    const b = document.createElement("button");
    b.className = "btn " + (a.cls || ""); b.innerHTML = a.label;
    b.onclick = () => { if (!a.fn || a.fn() !== false) close(); };
    acts.appendChild(b);
  });
  root.appendChild(ov);
  return close;
};
LQ.confetti = () => {
  const cv = document.getElementById("confetti"), ctx = cv.getContext("2d");
  cv.width = innerWidth; cv.height = innerHeight;
  const cols = ["#8b5cf6","#22d3ee","#fbbf24","#ec4899","#22c55e","#fff"];
  const ps = Array.from({length:130}, () => ({
    x: Math.random()*cv.width, y: -20 - Math.random()*cv.height*.3,
    s: 4+Math.random()*7, c: cols[Math.random()*cols.length|0],
    vy: 2+Math.random()*3.5, vx: -1.5+Math.random()*3, r: Math.random()*Math.PI
  }));
  const t0 = performance.now();
  (function tick(now){
    const k = (now - t0)/1000; ctx.clearRect(0,0,cv.width,cv.height);
    ps.forEach(p => { p.y += p.vy; p.x += p.vx; p.r += .07;
      ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.r);
      ctx.fillStyle = p.c; ctx.fillRect(-p.s/2,-p.s/2,p.s,p.s*.6); ctx.restore(); });
    if (k < 2.4) requestAnimationFrame(tick); else ctx.clearRect(0,0,cv.width,cv.height);
  })(t0);
};

/* ---------- УТИЛИТЫ ---------- */
LQ.qs = (s, r=document) => r.querySelector(s);
LQ.qsa = (s, r=document) => [...r.querySelectorAll(s)];
LQ.esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
LQ.shuffle = a => { a = [...a]; for (let i=a.length-1;i>0;i--){ const j = Math.random()*(i+1)|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };
LQ.fmtTime = sec => `${String(sec/60|0).padStart(2,"0")}:${String(sec%60|0).padStart(2,"0")}`;
LQ.baseWord = w => w[LQ.state.base].replace(/\([^)]*\)/g,"").trim(); // слово без уточнений в скобках

/* ---------- НАВИГАЦИЯ / РОУТЕР ---------- */
LQ.go = page => {
  if (!LQ.pages[page]) return;
  LQ.current = page;
  LQ.qsa(".page").forEach(p => p.classList.remove("active"));
  LQ.qs("#page-" + page).classList.add("active");
  LQ.qsa(".nav-btn, .mobile-nav button").forEach(b => b.classList.toggle("active", b.dataset.go === page));
  document.getElementById("navbar").classList.remove("nav-open");
  window.scrollTo({ top: 0, behavior: "smooth" });
  LQ.pages[page]();
};

/* ---------- ХРОМ (navbar, чип, i18n статики) ---------- */
LQ.syncChip = () => {
  if (!LQ.state?.user) return;
  LQ.qs("#chipAvatar").textContent = LQ.state.user.avatar;
  LQ.qs("#chipName").textContent = LQ.state.user.name;
  LQ.qs("#chipLvl").textContent = "Lv " + LQ.level().lvl;
  LQ.qs("#chipCoins").textContent = LQ.state.coins;
  document.getElementById("userChip").classList.toggle("framed", !!LQ.state.owned.frame);
};
LQ.applyI18n = () => {
  LQ.qsa("[data-i18n]").forEach(el => el.textContent = LQ.t(el.dataset.i18n));
  LQ.qsa("[data-i18n-ph]").forEach(el => el.placeholder = LQ.t(el.dataset.i18nPh));
};
LQ.applySkin = name => { LQ.state.theme = name; document.documentElement.dataset.theme = name; LQ.save(); };

/* ---------- РЕГИСТРАЦИЯ ---------- */
function initRegistration() {
  const ov = document.getElementById("regOverlay");
  if (LQ.state.user) { ov.classList.add("hidden"); return; }
  ov.classList.remove("hidden");

  // выбор языка интерфейса прямо на экране приветствия
  const rl = document.getElementById("regLangs");
  rl.innerHTML = "";
  ["ru","en","es","pt"].forEach(l => {
    const b = document.createElement("button");
    b.className = "rl-btn" + (LQ.state.uiLang === l ? " on" : "");
    b.textContent = LQ.FLAG[l] + " " + (I18N[l]["lang." + l] || l);
    b.onclick = () => {
      LQ.state.uiLang = l; LQ.save();
      document.getElementById("uiLang").value = l;
      LQ.applyI18n(); LQ.renderFootLinks();
      LQ.qsa(".rl-btn", rl).forEach(x => x.classList.toggle("on", x === b));
    };
    rl.appendChild(b);
  });

  let av = LQ.AV_FREE[0];
  const box = document.getElementById("regAvatars");
  box.innerHTML = "";
  LQ.AV_FREE.forEach((a,i) => {
    const b = document.createElement("button");
    b.className = "reg-av" + (i===0 ? " on" : ""); b.textContent = a;
    b.onclick = () => { av = a; LQ.qsa(".reg-av", box).forEach(x => x.classList.toggle("on", x === b)); LQ.fx("coin"); };
    box.appendChild(b);
  });
  document.getElementById("regStart").onclick = () => {
    const name = document.getElementById("regName").value.trim();
    if (!name) { LQ.toast(LQ.t("reg.needName")); return; }
    LQ.state.user = { name: LQ.esc(name), avatar: av };
    LQ.touchStreak(); LQ.save(); LQ.syncChip();
    ov.classList.add("hidden");
    LQ.confetti(); LQ.fx("level");
    LQ.go("home");
  };
  document.getElementById("regName").addEventListener("keydown", e => {
    if (e.key === "Enter") document.getElementById("regStart").click();
  });
}

/* ---------- ИНИЦИАЛИЗАЦИЯ ---------- */
document.addEventListener("DOMContentLoaded", () => {
  LQ.state = Store.get() || LQ.defaults();
  document.documentElement.dataset.theme = LQ.state.theme || "violet";
  document.getElementById("uiLang").value = LQ.state.uiLang || "ru";
  document.getElementById("year").textContent = new Date().getFullYear();

  // навигация
  LQ.qsa("[data-go]").forEach(b => b.addEventListener("click", () => LQ.go(b.dataset.go)));
  document.getElementById("burger").onclick = () => document.getElementById("navbar").classList.toggle("nav-open");
  document.querySelector(".brand").addEventListener("click", () => LQ.go("home"));

  // язык интерфейса
  document.getElementById("uiLang").addEventListener("change", e => {
    LQ.state.uiLang = e.target.value; LQ.save();
    LQ.applyI18n();
    LQ.renderFootLinks();
    if (LQ.state.user) LQ.go(LQ.current);
    LQ.renderWordsPanel && LQ.renderWordsPanel();
  });

  // профиль
  document.getElementById("userChip").onclick = () => LQ.openProfile && LQ.openProfile();

  // футер-ссылки
  LQ.renderFootLinks = () => {
    const fl = document.getElementById("footLinks"); fl.innerHTML = "";
    ["home","learn","tests","exam","progress","shop"].forEach(p => {
      const b = document.createElement("button");
      b.textContent = LQ.t("nav." + p); b.onclick = () => LQ.go(p);
      fl.appendChild(b);
    });
  };
  LQ.renderFootLinks();

  // панель слов
  const wp = document.getElementById("wordsPanel");
  document.getElementById("wordsBtn").onclick = () => {
    wp.classList.toggle("hidden");
    document.getElementById("wordsBtn").classList.toggle("open");
    if (!wp.classList.contains("hidden")) { LQ.renderWordsPanel(); LQ.qs("#wpSearch").focus(); }
  };
  document.getElementById("wpClose").onclick = () => { wp.classList.add("hidden"); document.getElementById("wordsBtn").classList.remove("open"); };
  document.getElementById("wpSearch").addEventListener("input", () => LQ.renderWordsPanel());

  LQ.applyI18n();

  // открыта чужая ссылка на профиль (?p=...)
  const sp = new URLSearchParams(location.search).get("p");
  if (sp && LQ.showShared) LQ.showShared(sp, () => { if (!LQ.state.user) initRegistration(); });
  if (LQ.state.user) { initRegistration(); LQ.syncChip(); LQ.go("home"); }
  else if (!sp) initRegistration();
});
