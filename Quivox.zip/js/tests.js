/* =====================================================
   QUIVOX — ТЕСТЫ (3 режима) + ЭКЗАМЕН
   Режимы: choice (1 из 5), write (написать), listen (на слух)
   ===================================================== */
"use strict";

/* ---------- Универсальная сессия ---------- */
const Session = {
  cur: null,
  stop(){ if (this.cur?.int) clearInterval(this.cur.int); this.cur = null; if ("speechSynthesis" in window) speechSynthesis.cancel(); },
};

const _go = LQ.go.bind(LQ);
LQ.go = p => { Session.stop(); _go(p); };

LQ.download = (name, html) => { // генерация документов (отчёты/сертификаты)
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
};

/* награды по режимам */
const REW = { choice:{c:5,x:8}, write:{c:8,x:10}, listen:{c:6,x:8} };
const REW_EXAM = { c:10, x:12 };

/* ================= СТРАНИЦА НАСТРОЙКИ ТЕСТА ================= */
const TS = { mode: "choice", theme: "*", count: 10 };

LQ.pages.tests = () => {
  const s = LQ.state;
  const mistN = LQ.mistakePool().length;

  LQ.qs("#page-tests").innerHTML = `
    <h2 class="section-title">🎯 ${LQ.t("t.title")} <small>${LQ.t("t.sub")}</small></h2>

    <div class="setup-label">${LQ.t("t.mode")}</div>
    <div class="mode-grid">
      ${[["choice","🎚","t.m1","t.m1d"],["write","⌨️","t.m2","t.m2d"],["listen","👂","t.m3","t.m3d"]].map(([m,ic,k,kd]) => `
        <div class="card mode-card ${TS.mode===m?"on":""}" data-mode="${m}">
          <div class="mi">${ic}</div><h3>${LQ.t(k)}</h3><p>${LQ.t(kd)}</p>
        </div>`).join("")}
    </div>

    <div class="setup-label">${LQ.t("t.theme")}</div>
    <div class="pill-row" id="tsThemes"></div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(230px,1fr))">
      <div>
        <div class="setup-label">${LQ.t("t.count")}</div>
        <div class="pill-row" id="tsCounts">
          ${[[10,"t.c10"],[20,"t.c20"],["all","t.call"]].map(([n,k]) =>
            `<button class="pill ${TS.count===n?"on":""}" data-cnt="${n}">${LQ.t(k)}</button>`).join("")}
        </div>
      </div>
      <div>
        <div class="setup-label">${LQ.t("t.dir")}</div>
        <div class="pill-row" style="align-items:center">
          <span class="muted" style="font-size:.8rem">${LQ.t("t.from")}</span>
          <select id="tsFrom" class="input"></select>
          <span class="muted" style="font-size:.8rem">${LQ.t("t.to")}</span>
          <select id="tsTo" class="input"></select>
        </div>
      </div>
    </div>

    <div id="tsBonus" class="bonus-note ${TS.theme==="*"?"":"hidden"}">${LQ.t("t.bonusAll")}</div>
    <button class="btn primary big glow" id="tsStart" style="margin-top:14px;width:100%">${LQ.t("t.start")}</button>
  `;

  // режим
  LQ.qsa("#page-tests .mode-card").forEach(c => c.onclick = () => {
    TS.mode = c.dataset.mode; LQ.fx("coin");
    LQ.qsa("#page-tests .mode-card").forEach(x => x.classList.toggle("on", x === c));
  });

  // темы
  const thRow = LQ.qs("#tsThemes");
  const mkTh = (id, icon, name, extra="") => {
    const b = document.createElement("button");
    b.className = "pill" + (TS.theme === id ? " on" : "");
    b.innerHTML = `${icon} ${LQ.esc(name)}${extra}`;
    b.onclick = () => { TS.theme = id; LQ.qsa("#tsThemes .pill").forEach(x => x.classList.toggle("on", x===b)); LQ.qs("#tsBonus").classList.toggle("hidden", id !== "*"); };
    thRow.appendChild(b);
  };
  mkTh("*", "🎲", LQ.t("t.all"));
  WORDS_DB.themes.forEach(th => mkTh(th.id, th.icon, th.title[s.uiLang] || th.title.ru));
  mkTh("mist", "⚠️", LQ.t("t.mistakes"), ` <span class="muted">· ${mistN}</span>`);

  // количество
  LQ.qsa("#tsCounts .pill").forEach(b => b.onclick = () => {
    TS.count = b.dataset.cnt === "all" ? "all" : +b.dataset.cnt;
    LQ.qsa("#tsCounts .pill").forEach(x => x.classList.toggle("on", x === b));
  });

  // направление
  const langs = ["ru","en","es","pt"];
  const from = LQ.qs("#tsFrom"), to = LQ.qs("#tsTo");
  from.innerHTML = langs.map(l => `<option value="${l}" ${l===s.base?"selected":""}>${LQ.langLabel(l)}</option>`).join("");
  to.innerHTML   = `<option value="all" ${s.target==="all"?"selected":""}>${LQ.langLabel("all")}</option>` +
    langs.map(l => `<option value="${l}" ${l===s.target?"selected":""}>${LQ.langLabel(l)}</option>`).join("");
  const guard = (changed, other) => {
    if (changed.value === other.value) other.value = langs.find(l => l !== changed.value);
    LQ.state.base = from.value; LQ.state.target = to.value; LQ.save();
  };
  from.onchange = () => guard(from, to);
  to.onchange = () => guard(to, from);

  // старт
  LQ.qs("#tsStart").onclick = () => {
    let pool;
    if (TS.theme === "mist") pool = LQ.shuffle(LQ.mistakePool());
    else pool = LQ.shuffle(TS.theme === "*" ? LQ.ALL : LQ.themeWords(TS.theme));
    if (!pool.length) { LQ.toast(LQ.t("t.noWords")); return; }
    if (TS.count !== "all") pool = pool.slice(0, Math.min(TS.count, pool.length));
    startSession({
      mode: TS.mode, dir: { q: from.value, a: to.value },
      pool, pageId: "#page-tests", isExam: false,
      bonus: TS.theme === "*" ? 1.1 : 1   // +10% за режим «Все слова»
    });
  };
};

/* ================= ДВИЖОК СЕССИИ ================= */
function startSession(cfg) {
  Session.stop();
  const S = Session.cur = {
    ...cfg, i: 0, right: 0, wrong: [], coins: 0, xp: 0,
    // режим «все языки»: язык каждого вопроса случайный
    poolLangs: cfg.dir.a === "all" ? cfg.pool.map(() => ["en","es","pt"][Math.random()*3|0]) : null,
    t0: Date.now(), locked: false,
    int: setInterval(() => {
      const el = LQ.qs("#sessTimer");
      if (el) el.textContent = "⏱ " + LQ.fmtTime(((Date.now() - S.t0)/1000)|0);
    }, 1000)
  };
  renderQ();
}

function qMode(S){ return S.isExam ? ["choice","write","listen"][Math.random()*3|0] : S.mode; }

function trackedLang(S){ // язык, за который идёт мастерство (учитывает «все языки»)
  const a = S.aL || (S.dir.a !== "all" ? S.dir.a : LQ.state.target);
  return a !== "ru" ? a : (S.dir.q !== "ru" ? S.dir.q : LQ.state.target);
}

function renderQ() {
  const S = Session.cur, w = S.pool[S.i], mode = (S.qm = qMode(S)); // режим вопроса фиксируем
  S.locked = false; // ФИКС БАГА: без этого после 1-го вопроса ответы не кликались
  S.aL = S.poolLangs ? S.poolLangs[S.i] : S.dir.a; // «все языки»: реальный язык этого вопроса
  const exam = S.isExam;
  const label = `${LQ.langLabel(S.dir.q)} → ${LQ.langLabel(S.aL)}`;
  let body = "";

  if (mode === "listen") {                    // слушаем изучаемый язык, отвечаем на родном
    S.aLang = S.dir.q; S.qLangAns = S.aL; S.listenWord = w[S.aL];
    body = `
      <div class="q-label">👂 ${LQ.t("sess.whatMeans")}</div>
      <button class="listen-big" id="listenBtn">🔊</button>`;
  } else {
    body = `
      <div class="q-label">${LQ.t("sess.translate")} · ${label}</div>
      <div class="q-word">${LQ.esc(w[S.dir.q].replace(/\([^)]*\)/g,"").trim())}</div>
      <div class="q-dir muted">${LQ.t("sess.q",{a:S.i+1,b:S.pool.length})}</div>`;
  }

  if (mode === "choice" || mode === "listen") {
    const optLang = mode === "listen" ? S.dir.q : S.aL;
    const correct = w[optLang];
    const dis = LQ.shuffle(LQ.ALL.filter(x => x.id !== w.id && LQ.clean(x[optLang]) !== LQ.clean(correct)))
                  .filter((x,i,arr) => arr.findIndex(y => LQ.clean(y[optLang]) === LQ.clean(x[optLang])) === i)
                  .slice(0,4).map(x => x[optLang]);
    const opts = LQ.shuffle([correct, ...dis]);
    body += `<div class="opts">${opts.map((o,i) =>
      `<button class="opt" data-v="${LQ.esc(LQ.clean(o))}"><span class="num">${i+1}</span> ${LQ.esc(o)}</button>`).join("")}</div>`;
    S.correctClean = LQ.clean(correct); S.correctRaw = correct;
  } else { // write
    body += `
      <div class="write-row">
        <input id="ansInput" class="input" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="${LQ.t("sess.writeph")}">
        <button class="btn primary" id="ansBtn">✓</button>
      </div>
      ${!exam ? `<button class="hint-btn" id="hintBtn">${LQ.t("t.hint",{n:LQ.state.owned.hints})}</button>` : ""}`;
    S.correctRaw = w[S.aL];
  }

  LQ.qs(S.pageId).innerHTML = `
    <div class="sess">
      <div class="sess-head">
        <span class="sess-q">${LQ.t("sess.q",{a:S.i+1,b:S.pool.length})}</span>
        <div class="progress-track" style="flex:1"><div class="progress-bar" style="width:${S.i/S.pool.length*100}%"></div></div>
        <span class="sess-timer" id="sessTimer">⏱ 00:00</span>
      </div>
      <div class="card q-card-box">${body}<div id="fbZone"></div></div>
      <div class="sess-foot">
        <button class="btn danger" id="sessQuit">✕ ${LQ.t("sess.finish")}</button>
        <button class="btn primary hidden" id="sessNext">${LQ.t("sess.next")}</button>
      </div>
    </div>`;

  // подсказка
  const hintBtn = LQ.qs("#hintBtn");
  if (hintBtn) hintBtn.onclick = () => {
    if (LQ.state.owned.hints <= 0) { LQ.toast(LQ.t("t.hintNone")); return; }
    LQ.state.owned.hints--; LQ.save();
    const v = LQ.variants(S.correctRaw)[0] || "";
    hintBtn.textContent = `${LQ.t("t.hintInfo",{n:v.length})} ${v[0]||""}${" _".repeat(Math.max(0,v.length-1))}`;
    hintBtn.disabled = true; LQ.fx("coin");
  };

  // обработчики ответа
  const answer = ok => { if (!S.locked){ S.locked = true; finishQ(ok, S.qm === "write" ? (LQ.qs("#ansInput")?.value || "") : null); } };

  if (mode === "choice" || mode === "listen") {
    LQ.qsa(".opt", LQ.qs(S.pageId)).forEach(b => b.onclick = () => {
      if (S.locked) return;
      const ok = b.dataset.v === S.correctClean;
      b.classList.add(ok ? "right" : "wrong");
      if (!ok) LQ.qsa(".opt", LQ.qs(S.pageId)).forEach(x => { if (x.dataset.v === S.correctClean) x.classList.add("right"); });
      answer(ok);
    });
    if (mode === "listen") {
      const lb = LQ.qs("#listenBtn");
      const play = () => { lb.classList.add("playing"); LQ.speak(S.listenWord, S.aL); setTimeout(()=>lb.classList.remove("playing"), 900); };
      lb.onclick = play; setTimeout(play, 350);
    }
  } else {
    const inp = LQ.qs("#ansInput"), btn = LQ.qs("#ansBtn");
    const check = () => {
      if (S.locked) return;
      const ok = LQ.checkAnswer(inp.value, S.correctRaw);
      inp.classList.add(ok ? "ok" : "no"); inp.disabled = true;
      answer(ok);
    };
    btn.onclick = check;
    inp.addEventListener("keydown", e => { if (e.key === "Enter") check(); });
    inp.focus();
  }

  LQ.qs("#sessQuit").onclick = () => finishSession();
  LQ.qs("#sessNext").onclick = () => { S.i++; if (S.i >= S.pool.length) finishSession(); else renderQ(); };
}

function finishQ(ok, typed) {
  const S = Session.cur, w = S.pool[S.i], mode = S.qm || S.mode;
  const lang = trackedLang(S);
  const rw = S.isExam ? REW_EXAM : REW[mode];

  const b = S.bonus || 1;
  const rc = Math.round(rw.c * b), rx = Math.round(rw.x * b); // бонус ×1.1 в режиме «Все слова»
  LQ.state.stats.total++;
  if (ok) {
    LQ.onCorrect(w.id, lang, mode, rc, rx);
    S.right++; S.coins += rc; S.xp += rx;
    LQ.fx("good"); LQ.fly("+" + rc + " 🪙");
  } else {
    LQ.addMistake(w.id, lang); LQ.bumpMast(w.id, lang, -15);
    S.wrong.push({ w, yours: typed ?? "—", lang: S.aL || S.dir.a });
    LQ.fx("bad"); LQ.save();
  }

  // произносим правильное слово
  const sayLang = S.aL || S.dir.a;
  LQ.speak(w[sayLang], sayLang);

  const zone = LQ.qs("#fbZone");
  zone.innerHTML = `<div class="fb ${ok ? "good" : "bad"}">
      ${ok ? "🎉 " + LQ.t("sess.good",{c:rc}) : "💥 " + LQ.t("sess.bad",{w:"<b>"+LQ.esc(S.correctRaw)+"</b>"})}
      <button class="speak-big spk" id="fbSpeak" style="width:40px;height:40px;font-size:1rem">🔊</button>
    </div>`;
  LQ.qs("#fbSpeak").onclick = () => LQ.speak(w[sayLang], sayLang);
  LQ.qsa(".opt", LQ.qs(S.pageId)).forEach(b => b.disabled = true);
  LQ.qs("#sessNext").classList.remove("hidden");
}

function finishSession() {
  const S = Session.cur;
  Session.stop();
  const total = S.pool.length, answered = S.right + S.wrong.length;
  const acc = answered ? S.right / answered : 0;
  const time = ((Date.now() - S.t0)/1000)|0;
  const st = LQ.state.stats;

  if (S.isExam) {
    st.exams++;
    const grade = acc >= .9 ? "A" : acc >= .75 ? "B" : acc >= .6 ? "C" : "F";
    const pass = acc >= .8;
    const rec = { date: Date.now(), acc: Math.round(acc*100), time, grade };
    LQ.state.exams.unshift(rec); LQ.state.exams = LQ.state.exams.slice(0,10);
    if (!st.bestExam || rec.acc > st.bestExam.acc) st.bestExam = rec;
    if (pass) { LQ.state.coins += 100; LQ.state.stats.earned += 100; LQ.addXp(50); LQ.confetti(); }
    LQ.save(); LQ.checkAch();
    renderExamResult(rec, S);
    return;
  }

  if (answered > 0) {
    st.tests++;
    if (answered >= 10 && acc > st.bestTest) st.bestTest = acc;
    LQ.save(); LQ.checkAch();
  }
  renderResults(S, acc, time);
}

/* ---------- РЕЗУЛЬТАТЫ ---------- */
function resultsHTML(S, acc, time, emoji) {
  const C = Math.round(acc*100);
  return `
  <div class="sess">
    <div class="card res-hero">
      <div class="res-emoji">${emoji}</div>
      <h2 style="margin-top:6px">${LQ.t("res.done")}</h2>
      <div class="res-grid">
        <div><div class="res-num a">${C}%</div><div class="muted">${LQ.t("res.acc")}</div></div>
        <div><div class="res-num t">${LQ.fmtTime(time)}</div><div class="muted">${LQ.t("res.time")}</div></div>
        <div><div class="res-num c">+${S.coins} 🪙</div><div class="muted">${LQ.t("res.earned")} · ${S.xp} XP</div></div>
      </div>
      <h3 class="section-title" style="text-align:left">🧐 ${LQ.t("res.mistakes")}</h3>
      <div style="text-align:left">
        ${S.wrong.length ? S.wrong.map(m => `
          <div class="mist-item">
            <span class="w">${LQ.esc(m.w[S.dir.q].replace(/\([^)]*\)/g,"").trim())}</span>
            ${m.yours !== "—" ? `<span class="yours">${LQ.esc(m.yours)}</span>` : ""}
            <span class="right">${LQ.esc(m.w[m.lang || S.dir.a])}</span>
            <button class="speak-big spk" data-spk="${m.w.id}" data-l="${m.lang || S.dir.a}" style="width:36px;height:36px;font-size:.95rem">🔊</button>
          </div>`).join("")
        : `<p class="muted">${LQ.t("res.noMist")}</p>`}
      </div>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:22px;flex-wrap:wrap">
        ${S.wrong.length ? `<button class="btn" id="resRetry">🔁 ${LQ.t("res.retry")}</button>` : ""}
        <button class="btn primary" id="resAgain">↻ ${LQ.t("res.again")}</button>
        <button class="btn" id="resNew">🎯 ${LQ.t("res.new")}</button>
      </div>
    </div>
  </div>`;
}

function renderResults(S, acc, time) {
  const emoji = acc === 1 ? "🏆" : acc >= .8 ? "🎉" : acc >= .5 ? "💪" : "📚";
  LQ.qs(S.pageId).innerHTML = resultsHTML(S, acc, time, emoji);
  if (acc === 1 && S.pool.length >= 10) LQ.confetti();
  bindResultButtons(S);
}

function bindResultButtons(S) {
  LQ.qsa(S.pageId + " [data-spk]").forEach(b => b.onclick = () => { const w = LQ.byId(b.dataset.spk); LQ.speak(w[b.dataset.l || S.dir.a], b.dataset.l || S.dir.a); });
  const retry = LQ.qs("#resRetry");
  if (retry) retry.onclick = () => startSession({ mode: S.mode, dir: S.dir, pool: LQ.shuffle(S.wrong.map(m => m.w)), pageId: S.pageId, isExam: false });
  const again = LQ.qs("#resAgain");
  if (again) again.onclick = () => startSession({ mode: S.mode, dir: S.dir, pool: LQ.shuffle(S.pool), pageId: S.pageId, isExam: false });
  const nw = LQ.qs("#resNew");
  if (nw) nw.onclick = () => LQ.go("tests");
}

/* ================= ЭКЗАМЕН ================= */
const EXAM_N = 20;

LQ.pages.exam = () => {
  const st = LQ.state.stats, s = LQ.state;
  LQ.qs("#page-exam").innerHTML = `
    <h2 class="section-title">⏱️ ${LQ.t("ex.title")}</h2>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
      <div class="card">
        <p class="muted" style="margin-bottom:14px">${LQ.t("ex.sub")}</p>
        <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:18px">
          ${[1,2,3,4].map(i => `<li style="padding:10px 14px;background:rgba(255,255,255,.04);border-radius:12px">${LQ.t("ex.rule"+i)}</li>`).join("")}
        </ul>
        <p style="margin-bottom:14px;font-weight:700">${LQ.langLabel(s.base)} → ${LQ.langLabel(s.target)}</p>
        <button class="btn primary big glow" id="examStart">${LQ.t("ex.start")} 🚀</button>
      </div>
      <div class="card">
        <div class="setup-label">${LQ.t("ex.best")}</div>
        ${st.bestExam
          ? `<div class="grade" style="font-size:2rem">${st.bestExam.grade}</div>
             <div style="font-size:1.4rem;font-weight:900;color:var(--accent2)">${st.bestExam.acc}%</div>
             <div class="muted" style="font-size:.8rem">⏱ ${LQ.fmtTime(st.bestExam.time)}</div>`
          : `<p class="muted" style="margin-top:8px">${LQ.t("pr.empty")}</p>`}
        <div class="setup-label" style="margin-top:18px">${LQ.t("ex.hist")}</div>
        ${s.exams.length ? `<table class="mini"><thead><tr><th>#</th><th>${LQ.t("pr.acc")}</th><th>${LQ.t("pr.time")}</th><th>${LQ.t("pr.grade")}</th></tr></thead>
          <tbody>${s.exams.slice(0,5).map((e,i) => `<tr><td>${i+1}</td><td>${e.acc}%</td><td>${LQ.fmtTime(e.time)}</td><td>${e.grade}</td></tr>`).join("")}</tbody></table>`
        : `<p class="muted" style="margin-top:8px;font-size:.85rem">${LQ.t("pr.empty")}</p>`}
      </div>
    </div>`;

  LQ.qs("#examStart").onclick = () => {
    const pool = LQ.shuffle(LQ.ALL).slice(0, Math.min(EXAM_N, LQ.ALL.length));
    startSession({ mode: "mixed", dir: { q: s.base, a: s.target }, pool, pageId: "#page-exam", isExam: true });
  };
};

function renderExamResult(rec, S) {
  const pass = rec.acc >= 80;
  const emoji = rec.grade === "A" ? "🏆" : rec.grade === "B" ? "🎉" : rec.grade === "C" ? "💪" : "📚";
  const gradeTxt = { A:"ex.gradeA", B:"ex.gradeB", C:"ex.gradeC", F:"ex.gradeF" }[rec.grade];

  LQ.qs("#page-exam").innerHTML = `
    <div class="sess">
      <div class="card res-hero">
        <div class="res-emoji">${emoji}</div>
        <div class="grade">${rec.grade}</div>
        <h2>${LQ.t(pass ? "ex.pass" : "ex.fail")} — ${LQ.t(gradeTxt)}</h2>
        <div class="res-grid">
          <div><div class="res-num a">${rec.acc}%</div><div class="muted">${LQ.t("res.acc")}</div></div>
          <div><div class="res-num t">${LQ.fmtTime(rec.time)}</div><div class="muted">${LQ.t("res.time")}</div></div>
          <div><div class="res-num c">${pass ? "+100 🪙" : "+0 🪙"}</div><div class="muted">${LQ.t("res.earned")}</div></div>
        </div>
        <h3 class="section-title" style="text-align:left">🧐 ${LQ.t("res.mistakes")}</h3>
        <div style="text-align:left">
          ${S.wrong.length ? S.wrong.map(m => `
            <div class="mist-item">
              <span class="w">${LQ.esc(m.w[S.dir.q].replace(/\([^)]*\)/g,"").trim())}</span>
              ${m.yours !== "—" ? `<span class="yours">${LQ.esc(m.yours)}</span>` : ""}
              <span class="right">${LQ.esc(m.w[m.lang || S.dir.a])}</span>
              <button class="speak-big spk" data-spk="${m.w.id}" data-l="${m.lang || S.dir.a}" style="width:36px;height:36px;font-size:.95rem">🔊</button>
            </div>`).join("")
          : `<p class="muted">${LQ.t("res.noMist")}</p>`}
        </div>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:22px">
          ${pass ? `<button class="btn primary glow" id="examCert">${LQ.t("ex.cert")}</button>` : ""}
          ${S.wrong.length ? `<button class="btn" id="resRetry">🔁 ${LQ.t("res.retry")}</button>` : ""}
          <button class="btn" id="examBack">↻ ${LQ.t("res.again")}</button>
        </div>
      </div>
    </div>`;
  if (pass) LQ.qs("#examCert").onclick = () => downloadCertificate(rec);
  LQ.qsa("#page-exam [data-spk]").forEach(b => b.onclick = () => { const w = LQ.byId(b.dataset.spk); LQ.speak(w[b.dataset.l || S.dir.a], b.dataset.l || S.dir.a); });
  const retry = LQ.qs("#resRetry");
  if (retry) retry.onclick = () => startSession({ mode: "choice", dir: S.dir, pool: LQ.shuffle(S.wrong.map(m => m.w)), pageId: "#page-exam", isExam: false });
  LQ.qs("#examBack").onclick = () => LQ.pages.exam();
}

/* ---------- СЕРТИФИКАТ (генерация документа) ---------- */
function downloadCertificate(rec) {
  const s = LQ.state;
  const date = new Date(rec.date).toLocaleDateString(s.uiLang);
  const html = `<!DOCTYPE html><html lang="${s.uiLang}"><head><meta charset="utf-8"><title>QUIVOX Certificate</title>
<style>
  body{font-family:Georgia,serif;background:#0a0e1a;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
  .cert{background:linear-gradient(145deg,#141a2e,#0e1424);border:10px solid #fbbf24;outline:4px solid #8b5cf6;border-radius:8px;
        max-width:760px;width:92%;padding:60px 50px;text-align:center;color:#eef2ff;box-shadow:0 0 80px rgba(139,92,246,.5)}
  .logo{font-size:2.2rem;font-weight:900}.logo b{color:#8b5cf6}
  h1{letter-spacing:6px;color:#fbbf24;margin:18px 0 6px;font-size:1.7rem;text-transform:uppercase}
  .name{font-size:2.4rem;font-weight:900;background:linear-gradient(90deg,#8b5cf6,#22d3ee);-webkit-background-clip:text;background-clip:text;color:transparent;margin:14px 0}
  .stats{display:flex;justify-content:center;gap:40px;margin:26px 0;font-size:1.15rem}
  .stats b{color:#22d3ee;font-size:1.6rem;display:block}
  .grade{font-size:3.4rem;color:#fbbf24;font-weight:900;text-shadow:0 0 30px #fbbf24}
  .foot{margin-top:34px;color:#8b93b0;font-size:.85rem;display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px}
  @media print{body{background:#fff}.cert{box-shadow:none}}
</style></head><body>
  <div class="cert">
    <div class="logo">🔮 QUI<b>VOX</b></div>
    <h1>🏅 ${LQ.t("ex.cert").replace("📜 ","")}</h1>
    <div>${LQ.t("prf.name")}: </div>
    <div class="name">${LQ.esc(s.user.name)}</div>
    <div>${LQ.t("ex.pass")} · ${LQ.langName(s.base)} → ${LQ.langName(s.target)}</div>
    <div class="stats">
      <div><b>${rec.acc}%</b>${LQ.t("pr.acc")}</div>
      <div><b>${LQ.fmtTime(rec.time)}</b>${LQ.t("pr.time")}</div>
      <div><span class="grade">${rec.grade}</span></div>
    </div>
    <div class="foot"><span>📅 ${date}</span><span>🔮 QUIVOX</span><span>© LEO USTIMOV</span></div>
  </div>
</body></html>`;
  LQ.download("QUIVOX-Certificate.html", html);
  LQ.toast("📜 ✓");
}
