/* =====================================================
   QUIVOX — БАЗА СЛОВ
   -----------------------------------------------------
   КАК ДОБАВИТЬ НОВЫЕ СЛОВА / ТЕМУ:
   1. Скопируй объект темы ниже, дай уникальный id.
   2. Варианты перевода пиши через " / " — любой из них
      будет засчитан как правильный ответ.
   3. Уточнения в скобках "(...)" игнорируются проверкой.
   ===================================================== */
const WORDS_DB = {
  themes: [
    {
      id: "city",
      icon: "🏙️",
      title: { ru: "Город", en: "City", es: "Ciudad", pt: "Cidade" },
      words: [
        { ru: "аэропорт",              en: "airport",          es: "aeropuerto",           pt: "aeroporto" },
        { ru: "бар",                   en: "bar",              es: "bar",                  pt: "bar" },
        { ru: "кинотеатр",             en: "cinema",           es: "cine",                 pt: "cinema" },
        { ru: "библиотека",            en: "library",          es: "librería",             pt: "livraria" },
        { ru: "ресторан",              en: "restaurant",       es: "restaurante",          pt: "restaurante" },
        { ru: "гостиница",             en: "hotel",            es: "hotel",                pt: "hotel" },
        { ru: "рынок",                 en: "market",           es: "mercado",              pt: "mercado" },
        { ru: "площадь",               en: "square",           es: "plaza",                pt: "praça" },
        { ru: "пляж",                  en: "beach",            es: "playa",                pt: "praia" },
        { ru: "школа",                 en: "school",           es: "escuela",              pt: "escola" },
        { ru: "университет",           en: "university",       es: "universidad",          pt: "universidade" },
        { ru: "больница",              en: "hospital",         es: "hospital",             pt: "hospital" },
        { ru: "здание",                en: "building",         es: "edificio",             pt: "prédio" },
        { ru: "страна",                en: "country",          es: "país",                 pt: "país" },
        { ru: "город",                 en: "city",             es: "ciudad",               pt: "cidade" },
        { ru: "деревня",               en: "village",          es: "aldea / pueblo",       pt: "aldeia" },
        { ru: "место",                 en: "place",            es: "lugar",                pt: "lugar" },
        { ru: "банк",                  en: "bank",             es: "banco",                pt: "banco" },
        { ru: "центр",                 en: "center",           es: "centro",               pt: "centro" },
        { ru: "район",                 en: "district",         es: "barrio",               pt: "bairro" },
        { ru: "дом",                   en: "house",            es: "casa",                 pt: "casa" },
        { ru: "зал (спорт)",           en: "gym",              es: "gimnasio",             pt: "academia" },
        { ru: "детский сад",           en: "kindergarten",     es: "jardín de infancia",   pt: "jardim de infância" },
        { ru: "квартира",              en: "flat / apartment", es: "apartamento",          pt: "apartamento" },
        { ru: "музей",                 en: "museum",           es: "museo",                pt: "museu" },
        { ru: "метро",                 en: "metro / subway",   es: "metro",                pt: "metrô" },
        { ru: "полицейский участок",   en: "police station",   es: "estación de policía",  pt: "delegacia" },
        { ru: "пожарная станция",      en: "fire station",     es: "estación de bomberos", pt: "corpo de bombeiros" },
        { ru: "станция поездов",       en: "railway station",  es: "estación de tren",     pt: "estação ferroviária" },
        { ru: "парк",                  en: "park",             es: "parque",               pt: "parque" },
        { ru: "кафе",                  en: "cafe",             es: "cafetería",            pt: "café" },
        { ru: "магазин",               en: "shop",             es: "tienda",               pt: "loja" },
        { ru: "автовокзал",            en: "bus station",      es: "estación de autobús",  pt: "rodoviária" },
        { ru: "зоопарк",               en: "zoo",              es: "zoológico",            pt: "zoológico" },
        { ru: "офис",                  en: "office",           es: "oficina",              pt: "escritório" },
        { ru: "стадион",               en: "stadium",          es: "estadio",              pt: "estádio" },
        { ru: "концертный зал",        en: "concert hall",     es: "sala de conciertos",   pt: "sala de concertos" },
        { ru: "церковь",               en: "church",           es: "iglesia",              pt: "igreja" },
        { ru: "кладбище",              en: "cemetery / graveyard", es: "cementerio",       pt: "cemitério" },
        { ru: "аквапарк",              en: "water park",       es: "parque acuático",      pt: "parque aquático" },
        { ru: "заправочная станция",   en: "gas station",      es: "gasolinera",           pt: "posto de gasolina" },
        { ru: "парковка",              en: "parking spot / space", es: "aparcamiento",     pt: "vaga de garagem" },
        { ru: "парикмахерская",        en: "barbershop",       es: "peluquería",           pt: "cabeleireiro" }
      ]
    },
    {
      id: "greet",
      icon: "👋",
      title: { ru: "Приветствия", en: "Greetings", es: "Saludos", pt: "Saudações" },
      words: [
        { ru: "привет",       en: "hello / hi",      es: "hola",                    pt: "olá" },
        { ru: "доброе утро",  en: "good morning",    es: "buenos días",             pt: "bom dia" },
        { ru: "добрый день",  en: "good afternoon",  es: "buenas tardes",           pt: "boa tarde" },
        { ru: "добрый вечер", en: "good evening",    es: "buenas noches",           pt: "boa noite" },
        { ru: "пока",         en: "bye / goodbye",   es: "adiós / chao",            pt: "tchau / adeus" },
        { ru: "спасибо",      en: "thank you",       es: "gracias",                 pt: "obrigado" },
        { ru: "пожалуйста",   en: "please / you're welcome", es: "por favor / de nada", pt: "por favor / de nada" },
        { ru: "извините",     en: "excuse me / sorry", es: "perdón / disculpe",     pt: "desculpe" },
        { ru: "да",           en: "yes",             es: "sí",                      pt: "sim" },
        { ru: "нет",          en: "no",              es: "no",                      pt: "não" }
      ]
    },
    // ===== ТЕМА: ТРАНСПОРТ (из Excel-таблицы) =====
    {
      id: "transport",      // объединённая тема: тянет слова из 3 подтем ниже
      icon: "🚌",
      combine: ["tr_ground", "tr_air", "tr_water"],
      title: { ru: "Весь транспорт", en: "All transport", es: "Todo el transporte", pt: "Todo o transporte" }
    },
    {
      id: "tr_ground",
      icon: "🚗",
      title: { ru: "Наземный транспорт", en: "Ground transportation", es: "Transporte terrestre", pt: "Transporte terrestre" },
      words: [
        { ru: "транспорт",            en: "transport",        es: "transporte",     pt: "transporte" },
        { ru: "скейтборд",            en: "skateboard",       es: "monopatín",      pt: "skate" },
        { ru: "велосипед",            en: "bicycle",          es: "bicicleta",      pt: "bicicleta" },
        { ru: "мотоцикл",             en: "bike / motorcycle", es: "motocicleta",   pt: "motocicleta" },
        { ru: "машина",               en: "car",              es: "coche",          pt: "carro" },
        { ru: "грузовик",             en: "truck",            es: "camión",         pt: "caminhão" },
        { ru: "поезд",                en: "train",            es: "tren",           pt: "trem" },
        { ru: "автобус",              en: "bus",              es: "autobús",        pt: "ônibus" },
        { ru: "трактор",              en: "tractor",          es: "tractor",        pt: "trator" },
        { ru: "самокат",              en: "scooter",          es: "patineta",       pt: "patinete" },
        { ru: "такси",                en: "taxi",             es: "taxi",           pt: "táxi" },
        { ru: "снегоход",             en: "snowmobile",       es: "moto de nieve",  pt: "moto de neve" },
        { ru: "квадроцикл",           en: "quad bike",        es: "cuatriciclo",    pt: "quadriciclo" },
        { ru: "машина скорой помощи", en: "ambulance",        es: "ambulancia",     pt: "ambulância" }
      ]
    },
    {
      id: "tr_air",
      icon: "✈️",
      title: { ru: "Воздушный транспорт", en: "Air transport", es: "Transporte aéreo", pt: "Transporte aéreo" },
      words: [
        { ru: "самолёт",          en: "plane",                     es: "avión",          pt: "avião" },
        { ru: "вертолёт",         en: "helicopter",                es: "helicóptero",    pt: "helicóptero" },
        { ru: "воздушный шар",    en: "air balloon / balloon",     es: "globo",          pt: "balão" },
        { ru: "дельтаплан",       en: "hang glider",               es: "ala delta",      pt: "asa-delta" },
        { ru: "истребитель",      en: "fighter jet",               es: "caza",           pt: "caça" },
        { ru: "ракета",           en: "rocket",                    es: "cohete / misil", pt: "foguete" },
        { ru: "дрон / беспилотник", en: "drone / fpv drone",       es: "drone",          pt: "drone" }
      ]
    },
    {
      id: "tr_water",
      icon: "🚤",
      title: { ru: "Водный транспорт", en: "Water transport", es: "Transporte fluvial", pt: "Transporte aquático" },
      words: [
        { ru: "водный скутер",   en: "water scooter",  es: "scooter de agua", pt: "scooter" },
        { ru: "лодка",           en: "boat",           es: "lancha / barco",  pt: "barco" },
        { ru: "корабль",         en: "ship",           es: "nave",            pt: "navio" },
        { ru: "подводная лодка", en: "submarine",      es: "submarino",       pt: "submarino" },
        { ru: "батискаф",        en: "bathyscaphe",    es: "batiscafo",       pt: "bathyscaphe" }
      ]
    }
  ]
};
